# Changelog

## 0.5.0 — 2026-11-01 (unpacked trial)

- Optional Chrome-running desktop reminders configured in Semester Web 0.16.0. Explicit device opt-in; alarms/notifications are optional permissions. No n8n, polling, Canvas writes or new mandatory host access.
- One next-alarm scheduler, saved-revision guards, account isolation, restart recovery, bounded sleep catch-up and duplicate-send protection. Cancel/completion/deletion and rescheduling preserve user intent. Notification clicks use a fixed Semester origin and account-checked item link.
- Separate settings/test/off UI and same-origin/top-frame message bridge. Reminder metadata/receipts are local; choices remain in the Semester account. Real installed-extension/OS acceptance is pending; mocked delivery does not prove OS behavior.


## 0.4.4 — 2026-10-31 (unpacked trial)

- Check all can use a signed-in Canvas dashboard as well as a course tab. Returning to Semester no longer requires opening a specific course first. No additional permissions, background polling or automatic imports.
- Preserve selected-course/account validation, one-minute throttling, atomic batch delivery and cancellation on navigation, login or permission changes. Dashboard navigation alone does not trigger a read.
- Reproduced the dashboard rejection before the fix; 57 Node tests pass afterwards. Real installed-Chrome permission/worker delivery remains a trial acceptance check, not proven by mocks.

## 0.4.3 — 2026-10-27 (unpacked)

- Reattach already-permitted Semester tabs when opening Connect after an extension reload. Keep a Reconnect to Semester action available for unchanged course selections without resetting pending previews or rate limits.
- Replace stale bridge instances and reuse healthy ones; describe saved consent as Connection enabled rather than implying that a website tab has confirmed receipt.
- All 55 Node checks pass, including stale-context reinjection, listener cleanup, reconnect permission requirements and preservation of previews/throttles. Real installed-Chrome recovery still needs a user check.

## 0.4.2 — 2026-10-27 (unpacked)

- Put the connection action directly after course selection. Explain setup once, later Canvas reloads and all-course checks.
- Collapse the manual read/download route under Manual import instead, with its own explanation. Restore connected selections for the same account and identify unsaved selection changes.
- Verified the setup, enabled state, changed selection, restored selection and manual read in a synthetic Chrome preview. All 50 Node extension checks pass.

## 0.4.1 — 2026-10-27 (unpacked)

- Add an always-visible Open Semester button and a next step after course checks are enabled. The manual JSON link stays available.

## 0.4.0 — 2026-10-24 (unpacked; live batch acceptance pending)

- Accept the fixed Semester website's **Check all N courses** request, restricted to the account/course IDs already explicitly enabled in Connect. One existing Canvas course tab is enough; no new tabs, arbitrary URLs, new permissions or automatic confirmation.
- Serialize the batch, coalesce concurrent requests, persist a one-minute batch throttle and publish a snapshot only when all selected courses succeed. Failure, interruption, account/permission changes or closing/navigating the source tab abort the batch without offering partial results.
- Keep single-course reload checks and JSON downloads. Explain why Enable is disabled. Queue bridge refreshes so a busy delivery cannot swallow the completion notification.
- Reader, lifecycle/security and four-course batch tests pass using synthetic inputs. Real installed-extension testing still requires reload and a fresh read; no live grades were imported in development.

## 0.3.0 — 2026-10-24 (unpacked; live acceptance pending)

- Add explicit opt-in reload checks for 1–8 selected USYD courses. Opening/reloading a selected course checks only that course; serialized reads and a one-minute/course throttle bound requests. No timers or Canvas writes.
- Request optional access only to USYD Canvas and the fixed Semester origin. Store consent/account/course IDs locally and pending source snapshots in session storage; expire snapshots after 24 hours, clear on disable/permission loss/account mismatch/read failure, and ignore in-flight results after navigation or disabling.
- Use a fixed-origin, top-frame bridge to Web 0.8.0's pending review. No credentials transferred, external messaging, generic URLs, automatic import or cloud grade writes. JSON export remains available without optional site access.
- Developer verification: reader and mocked lifecycle/security tests, synthetic web UI checks. Actual Chrome permission prompts and four-live-course reload delivery must still be tested by the user after deploying Web 0.8.0 and reloading Connect.

## 0.2.3 — 2026-10-20

- Require an actual numeric/text result as well as release evidence. A posted timestamp alone no longer marks an empty result as released.
- Unsubmitted work remains unsubmitted; blank pass/fail results are never inferred from numeric fallback scores or turned into zero.
- 35 Node tests and 89 browser DOMParser assertions pass, including posted-but-empty numeric/pass-fail cases.
- Existing 0.2.2 downloads still work with Semester Web 0.5.0. Reload/read/download again only to refresh the corrected release metadata; no timetable restore is needed.

## 0.2.2 — 2026-10-20

- Stop treating deprecated assignment-level `muted` as a student grade-release flag. Posted API grades and freshly confirmed Marks results can now be read even when that notification flag is true. Fresh Marks row visibility, pending-quiz, `grade_hidden` and excused checks still take priority.
- Read visible Complete/Incomplete icons and their accessibility labels as text results. Do not fabricate numerical scores or percentages; Semester Web's current calculator still imports only numeric marks.
- Distinguish numeric grades from text results in batch summaries, and explicitly label results withheld by Canvas.
- Check reader/preview/installed-manifest versions before reading and exporting; show reload/reopen instructions for mixed builds.
- Developer verification: 34 Node tests, 81 real-DOM browser assertions across four synthetic courses, preview selection/batch/filter/version-error checks and website import-protection regressions. No real account data was changed. Full installed-extension/four-live-course acceptance still requires reload and fresh comparison; restricted extension URLs prevented automated live-preview access.

## 0.2.1 — 2026-10-20

- Fix zero released grades caused by treating Canvas's initially hidden `grade-summary-content` loading wrapper as an unpublished-score signal. Actual muted/pending/hidden cells and What-If values remain excluded.
- Align course checkboxes horizontally with labels; add selected/focus states and larger clickable rows.
- Reload the unpacked extension, close old preview tabs, and read/download again. An older exported file cannot recover scores that were omitted at read time.

Semester Connect uses Semantic Versioning independently of Semester Web. During 0.x, incompatible changes increment the minor version and are documented. Bug fixes increment patch. Published build numbers are not reused.

## 0.2.0 — 2026-10-20

- Read up to eight explicitly selected teaching courses, retain successful previews, retry failed courses and download a versioned private import file for Semester Web 0.3.0.
- Verify student-course membership with the active student course list when single-course responses omit enrollment fields.
- Cross-check released numeric scores against a freshly fetched student Marks page. Ignore hidden, pending-review and What-If values; unsupported layouts are clearly reported.
- Canvas remains read-only with the same activeTab+scripting permissions. No automatic upload, background sync, cookies, token collection or extra host access.
- Website import requires mapping and confirmation and never overwrites existing manual data. Refresh the unpacked extension and reopen its preview to update.
- Synthetic tests cover four courses, failure/retry, release visibility, file export, import confirmation and existing-data protection. Live four-unit comparison remains required after reload.

## 0.1.0 — 2026-10-18

First local-only, manual read-only preview; not a Chrome Web Store release.

- USYD Canvas student course discovery and explicit single-course preview.
- Assignments, independent due/open/close dates, released marks and submission status.
- Assignment-group weights and drop rules shown as source facts, without grade forecasts.
- Sydney timezone, search, grade filter and Canvas source links.
- Active-tab permission only; no persistent grades, uploads or Semester writes.
- Safe GET allowlist, pagination, account checks, timeouts and conservative hidden-grade handling.
- SemVer shown in the extension UI; local loading and comparison guide.

Known limits: active enrollments only; no automatic syncing/import; release metadata can vary by Canvas installation. User comparison against live USYD Canvas is still required.
